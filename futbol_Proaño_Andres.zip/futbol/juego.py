from tkinter import *
tk=Tk()
x=0
y=0
canvas=Canvas(tk,width=450, height=326)
canvas.pack()

fondo=PhotoImage(file='campo.gif')
canvas.create_image(0,0, anchor=NW, image=fondo)

pelota=PhotoImage(file='ball.gif')
canvas.create_image(188,110, anchor=NW, image=pelota)

def mover(event):
	global x
	global y

	if event.keysym=='Up':
		canvas.move(2,0,-3)
		y=y-3
	elif event.keysym=='Down':
		canvas.move(2,0,3)
		y=y+3
	elif event.keysym=='Left':
		canvas.move(2,-3,0)
		x=x-4
	else:
		canvas.move(2,3,0)
		x=x+4


	if (x==256 or x==-260):
		#((x==256 or x==-260 ) and (y==125 or y==-125))
		gol=Tk()
		fin_juego='GOOOOOOOOOOOLLLLLLLLLL'
		msg= Message(gol, text=fin_juego)
		msg.config(bg='lightblue', font=('times',20,'bold'))
		msg.pack()
		gol.mainloop()

canvas.bind_all('<KeyPress-Up>',mover)
canvas.bind_all('<KeyPress-Down>',mover)
canvas.bind_all('<KeyPress-Left>',mover)
canvas.bind_all('<KeyPress-Right>',mover)
tk.mainloop()
